module.exports = {

  url: 'mongodb+srv://sk_faizani:<sEM1zU60pOJ599PD>@cluster0.8rxb6bo.mongodb.net/?retryWrites=true&w=majority'
  
  }